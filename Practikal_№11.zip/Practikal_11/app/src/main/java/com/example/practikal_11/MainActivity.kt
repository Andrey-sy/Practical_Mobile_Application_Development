package com.example.practikal_11

import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sunView = findViewById<ImageView>(R.id.sun)
        val sunRiseAnimation = AnimationUtils.loadAnimation(this, R.anim.sun_rise)
        sunView.startAnimation(sunRiseAnimation)

        val clockView = findViewById<ImageView>(R.id.clock)
        val clockTurnAnimation = AnimationUtils.loadAnimation(this, R.anim.clock_turn)
        clockView.startAnimation(clockTurnAnimation)

        val hourHandView = findViewById<ImageView>(R.id.hour_hand)
        val hourTurnAnimation = AnimationUtils.loadAnimation(this, R.anim.hour_turn)
        hourHandView.startAnimation(hourTurnAnimation)
    }
}