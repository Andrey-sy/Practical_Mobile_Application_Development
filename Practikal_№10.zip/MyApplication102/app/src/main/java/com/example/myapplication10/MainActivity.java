package com.example.myapplication10;

import android.app.Activity;

public class MainActivity extends Activity {
}
