package com.example.movieapp

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.myapplication10.R

class MainActivity : AppCompatActivity() {

    private val movieList = mutableListOf("Терминатор", "Титаник", "Матрица")
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextMovie = findViewById<EditText>(R.id.editText_movie)
        val buttonAdd = findViewById<Button>(R.id.button_add)
        val listViewMovies = findViewById<ListView>(R.id.listView_movies)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, movieList)
        listViewMovies.adapter = adapter

        buttonAdd.setOnClickListener {
            val name = editTextMovie.text.toString().trim()
            if (name.isNotEmpty()) {
                movieList.add(name)
                adapter.notifyDataSetChanged()
                editTextMovie.text.clear()
            } else {
                Toast.makeText(this, "Введите название фильма!", Toast.LENGTH_SHORT).show()
            }
        }

        listViewMovies.setOnItemLongClickListener { _, _, position, _ ->
            val filmName = movieList[position]
            movieList.removeAt(position)
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Фильм удалён: $filmName", Toast.LENGTH_SHORT).show()
            true
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_clear -> {
                clearAllMovies()
                true
            }
            R.id.menu_sort -> {
                sortMovies()
                true
            }
            R.id.menu_about -> {
                showAboutDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun clearAllMovies() {
        if (movieList.isNotEmpty()) {
            movieList.clear()
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Весь список очищен", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Список уже пуст", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sortMovies() {
        if (movieList.isNotEmpty()) {
            movieList.sort()
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Список отсортирован по алфавиту", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Список пуст, нечего сортировать", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("О приложении")
            .setMessage("Автор: Иван Иванов. Приложение 'Мой список фильмов'\n\nЭто приложение позволяет управлять списком ваших любимых фильмов: добавлять новые, удалять по долгому нажатию, сортировать и очищать весь список.")
            .setPositiveButton("OK", null)
            .show()
    }
}