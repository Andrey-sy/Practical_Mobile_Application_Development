package com.example.myapplication

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.zip.Inflater


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
             override fun onCreateOptionsMenu(menu: Menu?): Boolean {
                val Inflater = menuInflater
                menuInflater.inflate(R.menu.menu_main,menu)
                return super.onCreateOptionsMenu(menu)
            }
            menuInflater.inflate(R.menu.menu_main, android.R.menu)
            return super.onCreateOptionsMenu(android.R.menu)

            override fun onOptionsItemSelected(item: MenuItem): Boolean {
                return super.onOptionsItemSelected(item)
                val textView: TextView = findViewById(R.id.textView)
                when (item.itemId) {
                    R.id.action1 -> {
                        textView.text = "вы выбрали пунск 1!"
                        return true
                    }

                    R.id.action2 -> {
                        textView.text = "вы выбрали пунск 1!"
                        return true
                    }

                    R.id.action3 -> {
                        textView.text = "вы выбрали пунск 1!"
                        return true
                    }
                }
                return super.onOptionsItemSelected(item)
            }
            }
        }

