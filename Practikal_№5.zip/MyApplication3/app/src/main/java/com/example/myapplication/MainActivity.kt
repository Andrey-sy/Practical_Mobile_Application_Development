package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvLevel = findViewById<TextView>(R.id.tvLevel)
        val tvBonus = findViewById<TextView>(R.id.tvBonus)
        val tvTotalPower = findViewById<TextView>(R.id.tvTotalPower)
        val btnPlusLevel = findViewById<Button>(R.id.btnPlusLevel)
        val btnMinusLevel = findViewById<Button>(R.id.btnMinusLevel)
        val btnPlusBonus = findViewById<Button>(R.id.btnPlusBonus)
        val btnMinusBonus = findViewById<Button>(R.id.btnMinusBonus)
        val btnReset = findViewById<Button>(R.id.btnReset)

        var level = 1
        var bonus = 0

        fun updateDisplay() {
            tvLevel.text = level.toString()
            tvBonus.text = bonus.toString()
            val totalPower = level + bonus
            tvTotalPower.text = totalPower.toString()
        }

        btnPlusLevel.setOnClickListener {
            if (level < 10) {
                level++
                updateDisplay()
            } else {
                Toast.makeText(this, "Максимальный уровень достигнут!", Toast.LENGTH_SHORT).show()
            }
        }

        btnMinusLevel.setOnClickListener {
            if (level > 1) {
                level--
                updateDisplay()
            } else {
                Toast.makeText(this, "Минимальный уровень достигнут!", Toast.LENGTH_SHORT).show()
            }
        }

        btnPlusBonus.setOnClickListener {
            bonus++
            updateDisplay()
        }

        btnMinusBonus.setOnClickListener {
            if (bonus > 0) {
                bonus--
                updateDisplay()
            } else {
                Toast.makeText(this, "Бонус не может быть отрицательным!", Toast.LENGTH_SHORT).show()
            }
        }

        btnReset.setOnClickListener {
            level = 1
            bonus = 0
            updateDisplay()
            Toast.makeText(this, "Персонаж сброшен!", Toast.LENGTH_SHORT).show()
        }

        updateDisplay()
    }
}